import { Routes } from '@angular/router';
import { LoginComponent } from './component/login/login';
import { AuthGuard, GuestGuard } from './services/auth.guard';
import { AboutComponent } from './component/about/about';
import { UserLinksComponent } from './component/user-links/user-links';

export const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    canActivate: [GuestGuard] // Дозволено лише для неавторизованих користувачів
  },
  {
    path: 'main-window',
    canActivate: [AuthGuard], // Доступ лише для авторизованих користувачів
    loadComponent: () =>
      import('./component/main-window/main-window').then(m => m.UrlListComponent) // Динамічне завантаження компонента
  },
  {
    path: 'urls',
    component: UserLinksComponent,
    canActivate: [AuthGuard] // Захищаємо маршрут авторизацією
  },
  // ВАЖЛИВО: розміщуємо маршрут 'about' перед wildcard, щоб він не перехоплювався
  {
    path: 'about',
    component: AboutComponent
  },
  {
    path: '',
    redirectTo: '/main-window',  // Редирект з кореня на головне вікно
    pathMatch: 'full'
  },

  {
    path: '**',
    redirectTo: '/main-window'  // Якщо маршрут не знайдено — перенаправлення на головне вікно
  }
];
