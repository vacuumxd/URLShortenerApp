export const environment = {
  production: true,
  apiUrl: 'https://your-production-api-url/api'
};
