import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { routes } from './app.routes';
import { authInterceptor } from './services/auth.interceptor';

export const appConfig: ApplicationConfig = {
  providers: [
    // Глобальні обробники помилок у браузері (наприклад, uncaught exceptions)
    provideBrowserGlobalErrorListeners(),

    // Оптимізація зони змін (Zone.js) — обʼєднує події для зменшення кількості змін
    provideZoneChangeDetection({ eventCoalescing: true }),

    // Підключення HTTP-клієнта з інтерсептором для додавання токенів авторизації
    provideHttpClient(
      withInterceptors([authInterceptor])
    ),

    // Надання маршрутизатора з визначеними маршрутами застосунку
    provideRouter(routes)
  ]
};
