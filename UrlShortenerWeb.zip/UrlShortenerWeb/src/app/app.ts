import { Component, OnInit, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from './services/auth';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule],
  template: `
    <div class="app-container">
      <router-outlet></router-outlet> <!-- Місце для відображення маршрутів -->
    </div>
  `,
  styles: [`
    .app-container {
      min-height: 100vh;              /* Мінімальна висота — 100% висоти вікна */
      background-color: #f5f5f5;      /* Світло-сірий фон */
    }
  `]
})
export class App implements OnInit {
  // Назва застосунку (не використовується у шаблоні, але може бути корисною внутрішньо)
  protected title = 'UrlShortenerWeb';

  // Інʼєкція сервісу автентифікації
  private authService = inject(AuthService);

  ngOnInit(): void {
    // Ініціалізація сервісу автентифікації при запуску застосунку
    this.authService.initializeAuth();

    // Вивід статусу автентифікації у консоль для налагодження
    console.log('App initialized, isAuthenticated:', this.authService.isAuthenticated());
  }
}
