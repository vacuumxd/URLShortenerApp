import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth';

// Гард для захищених сторінок (вимагає аутентифікації)
export const AuthGuard = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  try {
    // Перевіряємо аутентифікацію з обробкою помилок
    if (authService.isAuthenticated()) {
      return true;
    } else {
      console.log('User is not authenticated, redirecting to login');
      // Очищаємо пошкоджені дані перед редіректом
      authService.clearCorruptedAuth();
      router.navigate(['/login']);
      return false;
    }
  } catch (error) {
    console.error('Error in AuthGuard:', error);
    // При будь-якій помилці очищуємо дані і редіректимо на логін
    authService.clearCorruptedAuth();
    router.navigate(['/login']);
    return false;
  }
};

// Гард для сторінок гостей (login, register) — забороняє доступ аутентифікованим користувачам
export const GuestGuard = () => {
  const authService = inject(AuthService);
  const router = inject(Router);

  try {
    // Якщо користувач вже аутентифікований, редіректимо на main-window
    if (authService.isAuthenticated()) {
      console.log('User already authenticated, redirecting to main-window');
      router.navigate(['/main-window']);
      return false;
    } else {
      // Користувач не аутентифікований — дозволяємо доступ до login/register
      return true;
    }
  } catch (error) {
    console.error('Error in GuestGuard:', error);
    // При помилці дозволяємо доступ до login
    return true;
  }
};
