import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';

export interface UrlEntry {
  id: number;
  originalUrl: string;
  shortCode: string;
}

@Injectable({
  providedIn: 'root'
})
export class UrlshortenerService {
  // Базова URL адреса API, звертайте увагу на порт, де працює сервер
  private apiUrl = 'http://localhost:5000/api/url'; // Порт 5000, бо сервер на ньому

  constructor(private http: HttpClient) { }

  // Отримати всі URL записи
  getAll(): Observable<UrlEntry[]> {
    return this.http.get<UrlEntry[]>(this.apiUrl).pipe(
      catchError(this.handleError) // Обробка помилок
    );
  }

  // Створити новий скорочений URL
  create(url: string): Observable<UrlEntry> {
    return this.http.post<UrlEntry>(this.apiUrl, { originalUrl: url }).pipe(
      catchError(this.handleError) // Обробка помилок
    );
  }

  // Отримати URL за shortCode (опціонально)
  getByShortCode(shortCode: string): Observable<UrlEntry> {
    return this.http.get<UrlEntry>(`${this.apiUrl}/${shortCode}`).pipe(
      catchError(this.handleError)
    );
  }

  // Видалити URL за id (опціонально)
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`).pipe(
      catchError(this.handleError)
    );
  }

  // Універсальна обробка помилок HTTP
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'Сталася невідома помилка';

    if (error.status === 0) {
      // Помилка мережі або CORS
      errorMessage = 'Не вдалося підключитися до сервера. Перевірте підключення і чи сервер запущений.';
      console.error('Помилка підключення:', error.error);
    } else if (error.status === 400) {
      errorMessage = 'Неправильний запит. Перевірте введені дані.';
    } else if (error.status === 404) {
      errorMessage = 'Ресурс не знайдено.';
    } else if (error.status === 500) {
      errorMessage = 'Внутрішня помилка сервера.';
    } else {
      errorMessage = `Помилка: ${error.status} - ${error.message}`;
    }

    console.error('Деталі помилки:', error);
    return throwError(() => new Error(errorMessage));
  }
}
