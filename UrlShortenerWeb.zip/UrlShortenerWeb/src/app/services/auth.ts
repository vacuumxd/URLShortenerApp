import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { tap, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { environment } from '../environments/environment';

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface AuthResponse {
  token: string;
  user: User;
  expires: string;
}

export interface User {
  id: string;
  username: string;
  email: string;
  createdAt: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly API_URL = environment.apiUrl || 'https://localhost:5001/api';
  private readonly TOKEN_KEY = 'authToken';
  private readonly USER_KEY = 'currentUser';

  private currentUserSubject = new BehaviorSubject<User | null>(this.getCurrentUser());
  public currentUser$ = this.currentUserSubject.asObservable();

  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(
    private http: HttpClient,
    private router: Router
  ) { }

  /**
   * Ініціалізація сервісу - викликати в app.component.ts
   */
  initializeAuth(): void {
    try {
      const token = this.getToken();
      if (token) {
        // Перевіряємо коректність токена під час ініціалізації
        if (this.isTokenValid(token)) {
          console.log('Дійсний токен знайдено при ініціалізації');
          // Переадресація тут не потрібна — її роблять Guard-и
        } else {
          console.log('Виявлено некоректний токен при ініціалізації, очищаємо');
          this.clearCorruptedAuth();
        }
      } else {
        console.log('Токен не знайдено при ініціалізації');
      }
    } catch (error) {
      console.error('Помилка при ініціалізації аутентифікації:', error);
      this.clearCorruptedAuth();
    }
  }

  /**
   * Перевірка валідності токена без побічних ефектів
   */
  private isTokenValid(token: string): boolean {
    if (!token || token === 'null' || token === 'undefined' || token.trim() === '') {
      return false;
    }

    try {
      const tokenParts = token.split('.');
      if (tokenParts.length !== 3) {
        return false;
      }

      const payload = this.decodeJwtPayload(tokenParts[1]);
      if (!payload) {
        return false;
      }

      const currentTime = Math.floor(Date.now() / 1000);
      return payload.exp && payload.exp > currentTime;
    } catch (error) {
      return false;
    }
  }

  /**
   * Вхід користувача
   */
  login(loginData: LoginRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.API_URL}/auth/login`, loginData, this.httpOptions)
      .pipe(
        tap(response => {
          this.setSession(response);
          console.log('Успішний вхід, переадресація на main-window');
          // Переадресація після успішного входу
          this.router.navigate(['/main-window']);
        })
      );
  }

  /**
   * Реєстрація користувача
   */
  register(registerData: RegisterRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.API_URL}/auth/register`, registerData, this.httpOptions)
      .pipe(
        tap(response => {
          this.setSession(response);
          console.log('Успішна реєстрація, переадресація на main-window');
          // Переадресація після успішної реєстрації
          this.router.navigate(['/main-window']);
        })
      );
  }

  /**
   * Вихід користувача
   */
  logout(): void {
    console.log('Виконуємо вихід користувача');
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    this.currentUserSubject.next(null);
    this.router.navigate(['/login']);
  }

  /**
   * Покращена перевірка аутентифікації
   */
  isAuthenticated(): boolean {
    const token = this.getToken();
    if (!token) {
      return false;
    }

    try {
      if (!this.isTokenValid(token)) {
        // Очищаємо лише якщо токен прострочений або пошкоджений
        this.clearCorruptedAuth();
        return false;
      }
      return true;
    } catch (error) {
      console.error('Помилка при перевірці токена:', error);
      this.clearCorruptedAuth();
      return false;
    }
  }

  /**
   * Декодування payload JWT з підтримкою URL-safe base64
   */
  private decodeJwtPayload(encodedPayload: string): any {
    try {
      // Конвертуємо URL-safe base64 у звичайний base64
      let base64 = encodedPayload.replace(/-/g, '+').replace(/_/g, '/');

      // Додаємо padding, якщо потрібно
      const padding = base64.length % 4;
      if (padding) {
        base64 += '='.repeat(4 - padding);
      }

      // Декодуємо base64
      const decodedData = atob(base64);

      // Парсимо JSON
      return JSON.parse(decodedData);
    } catch (error) {
      console.error('Помилка при декодуванні JWT payload:', error);
      return null;
    }
  }

  /**
   * Безпечне отримання токена з валідацією
   */
  getToken(): string | null {
    try {
      const token = localStorage.getItem(this.TOKEN_KEY);

      // Перевіряємо базові умови
      if (!token || token === 'null' || token === 'undefined' || token.trim() === '') {
        return null;
      }

      const cleanToken = token.trim();

      // Базова перевірка формату JWT (має містити 2 крапки)
      if (cleanToken.split('.').length !== 3) {
        console.warn('Токен має неправильний формат, очищуємо');
        this.clearCorruptedAuth();
        return null;
      }

      return cleanToken;
    } catch (error) {
      console.error('Помилка при отриманні токена:', error);
      this.clearCorruptedAuth();
      return null;
    }
  }

  /**
   * Очищення пошкоджених даних аутентифікації
   */
  clearCorruptedAuth(): void {
    console.log('Очищення пошкоджених даних аутентифікації');
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
    this.currentUserSubject.next(null);
  }

  /**
   * Отримання поточного користувача
   */
  getCurrentUser(): User | null {
    const userJson = localStorage.getItem(this.USER_KEY);
    if (userJson && userJson !== 'null' && userJson !== 'undefined') {
      try {
        return JSON.parse(userJson);
      } catch (error) {
        console.error('Помилка при парсингу користувача:', error);
        localStorage.removeItem(this.USER_KEY); // Очищаємо некоректні дані
        return null;
      }
    }
    return null;
  }

  /**
   * Оновлення профілю користувача
   */
  updateProfile(userData: Partial<User>): Observable<User> {
    return this.http.put<User>(`${this.API_URL}/auth/profile`, userData, this.getAuthHeaders())
      .pipe(
        tap(updatedUser => {
          this.updateStoredUser(updatedUser);
        })
      );
  }

  /**
   * Зміна пароля
   */
  changePassword(currentPassword: string, newPassword: string): Observable<any> {
    const changePasswordData = {
      currentPassword,
      newPassword
    };
    return this.http.post(`${this.API_URL}/auth/change-password`, changePasswordData, this.getAuthHeaders());
  }

  /**
   * Перевірка доступності імені користувача
   */
  checkUsernameAvailability(username: string): Observable<{ available: boolean }> {
    return this.http.get<{ available: boolean }>(`${this.API_URL}/auth/check-username/${username}`);
  }

  /**
   * Перевірка доступності email
   */
  checkEmailAvailability(email: string): Observable<{ available: boolean }> {
    return this.http.get<{ available: boolean }>(`${this.API_URL}/auth/check-email/${email}`);
  }

  /**
   * Забули пароль
   */
  forgotPassword(email: string): Observable<any> {
    return this.http.post(`${this.API_URL}/auth/forgot-password`, { email }, this.httpOptions);
  }

  /**
   * Скидання пароля
   */
  resetPassword(token: string, newPassword: string): Observable<any> {
    return this.http.post(`${this.API_URL}/auth/reset-password`, {
      token,
      newPassword
    }, this.httpOptions);
  }

  /**
   * Оновлення токена
   */
  refreshToken(): Observable<AuthResponse> {
    const token = this.getToken();
    if (!token) {
      throw new Error('Токен не знайдено');
    }

    return this.http.post<AuthResponse>(`${this.API_URL}/auth/refresh`, {}, this.getAuthHeaders())
      .pipe(
        tap(response => {
          this.setSession(response);
        })
      );
  }

  /**
   * Встановлення сесії після успішної аутентифікації
   */
  private setSession(authResponse: AuthResponse): void {
    if (authResponse && authResponse.token && authResponse.user) {
      localStorage.setItem(this.TOKEN_KEY, authResponse.token);
      localStorage.setItem(this.USER_KEY, JSON.stringify(authResponse.user));
      this.currentUserSubject.next(authResponse.user);
    } else {
      console.error('Некоректна відповідь аутентифікації:', authResponse);
    }
  }

  /**
   * Оновлення даних користувача у localStorage
   */
  private updateStoredUser(user: User): void {
    localStorage.setItem(this.USER_KEY, JSON.stringify(user));
    this.currentUserSubject.next(user);
  }

  /**
   * Отримання заголовків з авторизацією
   */
  private getAuthHeaders(): { headers: HttpHeaders } {
    const token = this.getToken();
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      })
    };
  }
}
