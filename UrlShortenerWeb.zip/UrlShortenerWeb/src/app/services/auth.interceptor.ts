import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, switchMap } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { AuthService } from './auth';

// HTTP інтерсептор для додавання токена авторизації в заголовки запитів
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const token = authService.getToken();

  // Якщо токен є — додаємо його в заголовки
  if (token) {
    req = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  return next(req).pipe(
    catchError(error => {
      // Якщо отримали 401 — пробуємо оновити токен
      if (error.status === 401) {
        return authService.refreshToken().pipe(
          switchMap(() => {
            // Після оновлення токена повторюємо запит з новим токеном
            const newToken = authService.getToken();
            const newReq = req.clone({
              setHeaders: {
                Authorization: `Bearer ${newToken}`
              }
            });
            return next(newReq);
          }),
          catchError(() => {
            // Якщо оновлення токена не вдалося — вихід з системи
            authService.logout();
            return throwError(() => error);
          })
        );
      }
      // Інші помилки передаємо далі
      return throwError(() => error);
    })
  );
};
