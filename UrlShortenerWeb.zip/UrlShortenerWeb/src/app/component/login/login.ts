import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService, AuthResponse } from '../../services/auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup; // Форма входу
  registerForm!: FormGroup; // Форма реєстрації
  isLoginMode = true;  // Режим: true — вхід, false — реєстрація
  isLoading = false;  // Індикатор завантаження
  hidePassword = true; // Сховати/показати пароль
  hideConfirmPassword = true;
  errorMessage = '';  // Повідомлення про помилки
  returnUrl = '';  // URL для повернення після входу

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute
  ) {
    this.initializeForms();
  }

  ngOnInit(): void {
    // Отримуємо URL, на який потрібно повернутись після входу
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/main-window';

    // Якщо вже авторизований — перенаправляємо
    if (this.authService.isAuthenticated()) {
      this.navigateAfterLogin();
    }
  }


  // Ініціалізація форм

  private initializeForms(): void {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });

    this.registerForm = this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });
  }

  // Валідатор: перевірка на збіг паролів
  private passwordMatchValidator(form: FormGroup) {
    const password = form.get('password');
    const confirmPassword = form.get('confirmPassword');

    if (password && confirmPassword && password.value !== confirmPassword.value) {
      confirmPassword.setErrors({ passwordMismatch: true });
      return { passwordMismatch: true };
    }

    return null;
  }


  // Обробка натискання на кнопку входу/реєстрації
  onSubmit(): void {
    const form = this.isLoginMode ? this.loginForm : this.registerForm;

    if (form.invalid) {
      this.markFormGroupTouched(form);
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    if (this.isLoginMode) {
      this.login();
    } else {
      this.register();
    }
  }

  private login(): void {
    const loginData = this.loginForm.value;

    this.authService.login(loginData).subscribe({
      next: (response: AuthResponse) => {
        console.log('Успешный вход:', response);
        this.navigateAfterLogin();
      },
      error: (error: any) => {
        console.error('Ошибка входа:', error);
        this.errorMessage = error.error?.message || 'Неверные учетные данные';
        this.isLoading = false;
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }


  // Реєстрація нового користувача
  private register(): void {
    const registerData = this.registerForm.value;

    this.authService.register(registerData).subscribe({
      next: (response: AuthResponse) => {
        console.log('Успешная регистрация:', response);
        this.isLoginMode = true;
        this.errorMessage = '';
        // Показываем сообщение об успешной регистрации
        alert('Регистрация прошла успешно! Теперь войдите в систему.');
      },
      error: (error: any) => {
        console.error('Ошибка регистрации:', error);
        this.errorMessage = error.error?.message || 'Ошибка при регистрации';
        this.isLoading = false;
      },
      complete: () => {
        this.isLoading = false;
      }
    });
  }

  // Навігація після успішного входу
  private navigateAfterLogin(): void {
    this.router.navigate(['/main-window']);
  }

  // Переключення між режимами: вхід ↔ реєстрація
  switchMode(): void {
    this.isLoginMode = !this.isLoginMode;
    this.errorMessage = '';
    this.resetForms();
  }

  private resetForms(): void {
    this.loginForm.reset();
    this.registerForm.reset();
  }


  // Позначити всі поля форми як "зачеплені" для виводу помилок
  private markFormGroupTouched(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(key => {
      const control = formGroup.get(key);
      control?.markAsTouched();
    });
  }

  // Геттер для поточної активної форми
  get currentForm(): FormGroup {
    return this.isLoginMode ? this.loginForm : this.registerForm;
  }

  get username() {
    return this.currentForm.get('username');
  }

  get email() {
    return this.registerForm.get('email');
  }

  get password() {
    return this.currentForm.get('password');
  }

  get confirmPassword() {
    return this.registerForm.get('confirmPassword');
  }
}
