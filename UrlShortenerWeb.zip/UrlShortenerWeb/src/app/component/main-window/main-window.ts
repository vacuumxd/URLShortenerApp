import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UrlshortenerService, UrlEntry } from '../../services/url-service';
import { AuthService, User } from '../../services/auth';
import { HttpClientModule } from '@angular/common/http';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-url-list',
  standalone: true,
  imports: [CommonModule, HttpClientModule, ReactiveFormsModule, RouterModule],
  templateUrl: './main-window.html',
  styleUrl: './main-window.css'
})
export class UrlListComponent implements OnInit {
  // Масив для збереження списку коротких URL
  urls: UrlEntry[] = [];

  // Поточний авторизований користувач
  currentUser: User | null = null;

  // Форми для роботи з URL
  getURLFrom!: FormGroup;           // Форма для створення короткої URL
  getOrignalURLFrom!: FormGroup;    // Форма для отримання оригінальної URL за короткою

  // Змінні для відображення результатів
  shortenedURL: string = '';         // Збережена коротка URL після створення
  orignalURL: string = '';           // Оригінальна URL після пошуку по короткій

  constructor(
    private urlService: UrlshortenerService,   // Сервіс для роботи з URL
    private authService: AuthService,           // Сервіс аутентифікації
    private formBuilder: FormBuilder,           // Фабрика форм
    private router: Router                       // Сервіс маршрутизації
  ) {
    this.initializeForms(); // Ініціалізація форм при створенні компонента
  }

  ngOnInit(): void {
    // Підписка на поточного користувача для отримання його даних
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });

    // Завантаження списку коротких URL користувача при ініціалізації компонента
    this.loadUrls();
  }

  // Ініціалізація форм з валідацією
  initializeForms(): void {
    // Форма для введення довгої URL з валідацією (обов’язково, починається з http або https)
    this.getURLFrom = this.formBuilder.group({
      url: ['', [Validators.required, Validators.pattern(/^https?:\/\/.+/)]]
    });

    // Форма для введення короткої URL з валідацією (обов’язково)
    this.getOrignalURLFrom = this.formBuilder.group({
      shortURL: ['', [Validators.required]]
    });
  }

  // Геттери для зручного доступу до полів форм у шаблоні
  get url() {
    return this.getURLFrom.get('url');
  }

  get shortURL() {
    return this.getOrignalURLFrom.get('shortURL');
  }

  // Метод виходу з системи
  logout(): void {
    this.authService.logout();
  }

  // Обробка відправки форми створення короткої URL
  onSubmit(): void {
    if (this.getURLFrom.valid) {
      const originalUrl = this.getURLFrom.value.url;

      // Виклик сервісу для створення короткої URL
      this.urlService.create(originalUrl).subscribe({
        next: (response: UrlEntry) => {
          // Формування повної короткої URL для відображення користувачу
          this.shortenedURL = `http://localhost:5000/${response.shortCode}`;

          // Оновлення списку посилань, щоб додати нове
          this.loadUrls();

          // Очищення форми після успішного створення
          this.getURLFrom.reset();
        },
        error: (error: any) => {
          console.error('Error to create short URL:', error);
          alert('Error to create short URL: ' + error.message);
        }
      });
    }
  }

  // Метод отримання оригінальної URL по короткій
  getOrignalURL(): void {
    if (this.getOrignalURLFrom.valid) {
      const shortUrlInput = this.getOrignalURLFrom.value.shortURL;

      // Витягуємо короткий код із повної URL (якщо користувач ввів повний URL)
      let shortCode = shortUrlInput;
      if (shortUrlInput.includes('/')) {
        shortCode = shortUrlInput.split('/').pop() || shortUrlInput;
      }

      // Шукаємо короткий код у локальному масиві (щоб не робити зайвий запит)
      const foundUrl = this.urls.find(url => url.shortCode === shortCode);

      if (foundUrl) {
        // Якщо знайшли — відкриваємо оригінальну URL в новій вкладці
        this.orignalURL = foundUrl.originalUrl;
        window.open(this.orignalURL, '_blank');

        // Очищуємо форму
        this.getOrignalURLFrom.reset();
      } else {
        // Якщо не знайшли локально — звертаємось до сервера
        this.urlService.getByShortCode(shortCode).subscribe({
          next: (response: UrlEntry) => {
            this.orignalURL = response.originalUrl;
            window.open(this.orignalURL, '_blank');

            // Очищуємо форму
            this.getOrignalURLFrom.reset();
          },
          error: (error: any) => {
            console.error('Error retrieving original URL:', error);
            alert('Short URL not found ' + error.message);
          }
        });
      }
    }
  }

  // Копіювання короткої URL у буфер обміну
  copyToClipboard(): void {
    if (this.shortenedURL) {
      navigator.clipboard.writeText(this.shortenedURL).then(() => {
        alert('Link is copied in clipboard');
      }).catch(err => {
        console.error('Copying error:', err);
        alert('Error copying to clipboard');
      });
    } else {
      alert('No links for copying');
    }
  }

  // Завантаження списку коротких URL для користувача
  private loadUrls(): void {
    this.urlService.getAll().subscribe({
      next: (data) => {
        this.urls = data;
      },
      error: (error: any) => {
        console.error('Error on download URL:', error);
        // Якщо сесія користувача не авторизована — вийти з системи
        if (error.status === 401) {
          this.authService.logout();
        }
      }
    });
  }

  // Видалення короткої URL за її ID
  deleteUrl(id: number): void {
    if (confirm('Are you sure, you want to delete that link?')) {
      this.urlService.delete(id).subscribe({
        next: () => {
          this.loadUrls(); // Оновлюємо список після видалення
          alert('Link succesfull deleted');
        },
        error: (error: any) => {
          console.error('Error on deleting:', error);
          alert('Error deleting link: ' + error.message);
        }
      });
    }
  }

  // Формування повної короткої URL для відображення у списку
  getFullShortUrl(shortCode: string): string {
    return `http://localhost:5000/${shortCode}`;
  }
}
