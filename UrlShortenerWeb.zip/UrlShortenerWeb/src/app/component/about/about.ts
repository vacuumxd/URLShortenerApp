import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

// Інтерфейс для структури інформації про застосунок
interface AppInfo {
  version: string;
  releaseDate: string;
  features: string[];
  developers: Developer[];
}

// Інтерфейс для опису розробника
interface Developer {
  name: string;
  role: string;
  email?: string; 
}

@Component({
  selector: 'app-about',  
  templateUrl: './about.html',
  imports: [CommonModule], // Імпортуємо спільний функціонал (наприклад, ngIf, ngFor)
  styleUrls: ['./about.css'] 
})
export class AboutComponent implements OnInit {
  // Початкове значення — порожні дані (заповниться після запиту)
  appInfo: AppInfo = {
    version: '',
    releaseDate: '',
    features: [],
    developers: []
  };

  // Інʼєкція HTTP-клієнта та роутера
  constructor(private http: HttpClient, private router: Router) { }

  // Метод життєвого циклу — викликається при ініціалізації компонента
  ngOnInit(): void {
    this.loadAppInfo(); // Завантаження даних про застосунок
  }

  // Перехід назад до головного вікна
  goBack(): void {
    this.router.navigate(['/main-window']);
  }

  // Завантаження інформації про застосунок з API
  loadAppInfo(): void {
    this.http.get<AppInfo>('/api/about/info').subscribe({
      next: (data) => {
        this.appInfo = data; // Якщо запит вдався — зберігаємо дані
      },
      error: (error) => {
        console.error('Error loading app info:', error); // Вивід помилки
        this.loadFallbackData(); // Якщо помилка — використовуємо резервні дані
      }
    });
  }

  // Резервні дані на випадок помилки запиту
  private loadFallbackData(): void {
    this.appInfo = {
      version: '1.0.0',
      releaseDate: '2025-06-15',
      features: [
        'Shorting long URL',        // Скорочення довгих посилань
        'Analytic of links',        // Аналітика за посиланнями
        'QR-codes for links'        // Генерація QR-кодів для посилань
      ],
      developers: [
        {
          name: 'Vyacheslav Vyrodov',
          role: 'Full Stack Developer',
          email: 'vyrodovslava@gmail.com'
        }
      ]
    };
  }
}
