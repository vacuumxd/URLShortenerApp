import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserLinks } from './user-links';

describe('UserLinks', () => {
  let component: UserLinks;
  let fixture: ComponentFixture<UserLinks>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UserLinks]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserLinks);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
