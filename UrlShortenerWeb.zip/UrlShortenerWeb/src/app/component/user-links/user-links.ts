import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { UrlshortenerService, UrlEntry } from '../../services/url-service';

@Component({
  selector: 'app-user-links',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './user-links.html',
  styleUrls: ['./user-links.css']
})
export class UserLinksComponent implements OnInit {
  // Масив посилань користувача
  links: UrlEntry[] = [];

  // Прапор для відображення стану завантаження
  loading = false;

  // Змінна для збереження тексту помилки, якщо вона є
  error: string | null = null;

  constructor(private urlService: UrlshortenerService) { }

  ngOnInit(): void {
    // При ініціалізації компонента завантажуємо посилання
    this.loadLinks();
  }

  // Метод для завантаження посилань з сервера
  loadLinks(): void {
    this.loading = true;   // Встановлюємо прапор завантаження в true
    this.error = null;     // Очищаємо попередні помилки

    this.urlService.getAll().subscribe({
      next: (links) => {
        this.links = links;  // Зберігаємо отримані посилання
        this.loading = false; // Завантаження завершено
      },
      error: (error) => {
        this.error = error.message;  // Зберігаємо текст помилки
        this.loading = false;        // Завантаження завершено з помилкою
        console.error('Error loading links:', error);
      }
    });
  }

  // Формуємо повний URL для короткого коду
  getShortUrl(shortCode: string): string {
    return `http://localhost:5000/${shortCode}`;
  }

  // Копіювання URL у буфер обміну
  copyToClipboard(url: string): void {
    navigator.clipboard.writeText(url).then(() => {
      this.showNotification('Link is copied in clipboard!');
    }).catch(() => {
      // Фолбек для старих браузерів, які не підтримують navigator.clipboard
      const textArea = document.createElement('textarea');
      textArea.value = url;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      this.showNotification('Link is copied in clipboard!');
    });
  }

  // Видалення посилання за запитом користувача
  deleteLink(link: UrlEntry): void {
    if (confirm(`Are you sure you want to delete the link? "${link.shortCode}"?`)) {
      this.urlService.delete(link.id).subscribe({
        next: () => {
          // Вилучаємо посилання з локального масиву після успішного видалення
          this.links = this.links.filter(l => l.id !== link.id);
          this.showNotification('Link successfull deleted!');
        },
        error: (error) => {
          console.error('Error deleting link:', error);
          alert('Error deleting link: ' + error.message);
        }
      });
    }
  }

  // Відкриваємо оригінальну URL у новій вкладці
  openOriginalUrl(url: string): void {
    let fullUrl = url;

    // Додаємо https:// якщо в URL немає протоколу
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      fullUrl = 'https://' + url;
    }

    window.open(fullUrl, '_blank');
  }

  // Оновлення списку посилань (повторне завантаження)
  refreshList(): void {
    this.loadLinks();
  }

  // Відображення простого повідомлення користувачу (toast)
  private showNotification(message: string): void {
    // Створюємо елемент повідомлення
    const notification = document.createElement('div');
    notification.className = 'alert alert-success position-fixed';
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '9999';
    notification.style.minWidth = '300px';
    notification.textContent = message;

    // Додаємо повідомлення у DOM
    document.body.appendChild(notification);

    // Через 3 секунди видаляємо повідомлення
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 3000);
  }
}
