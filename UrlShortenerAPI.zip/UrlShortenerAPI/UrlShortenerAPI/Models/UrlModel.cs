namespace UrlShortener.Models
{
    public class UrlModel
    {
        public int Id { get; set; }
        public string OriginalUrl { get; set; } = string.Empty;
        public string ShortCode { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public int ClickCount { get; set; } = 0;
        public string RequestId { get; set; } = string.Empty; // �������� �������������
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }

    public class CreateUrlRequest
    {
        public string OriginalUrl { get; set; } = string.Empty;
        public string? CustomCode { get; set; }
    }

    public class UrlResponse
    {
        public string OriginalUrl { get; set; } = string.Empty;
        public string ShortCode { get; set; } = string.Empty;
        public string ShortUrl { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public int ClickCount { get; set; }
    }


}