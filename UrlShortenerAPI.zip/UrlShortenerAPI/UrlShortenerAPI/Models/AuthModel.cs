﻿using System.Text;
using System.Text.Json;

namespace UrlShortenerAPI.Models
{
    // Represents data sent during user registration
    public class RegisterRequest
    {
        public string Email { get; set; } = string.Empty;             // User email
        public string Password { get; set; } = string.Empty;          // Password
        public string ConfirmPassword { get; set; } = string.Empty;   // Password confirmation
        public string? FirstName { get; set; }                        // Optional first name
        public string? LastName { get; set; }                         // Optional last name
    }

    // Represents data sent during user login
    public class LoginRequest
    {
        public string Email { get; set; } = string.Empty;             // User email
        public string Password { get; set; } = string.Empty;          // Password
    }

    // Response returned after successful authentication
    public class AuthResponse
    {
        public string Message { get; set; } = string.Empty;           // Optional status or success message
        public string Token { get; set; } = string.Empty;             // JWT token
        public UserInfo User { get; set; } = new UserInfo();          // Basic user info
    }

    // Basic user information included in AuthResponse
    public class UserInfo
    {
        public int Id { get; set; }                                   // User ID
        public string Email { get; set; } = string.Empty;             // User email
        public string Name { get; set; } = string.Empty;              // Full name or display name
    }
}
