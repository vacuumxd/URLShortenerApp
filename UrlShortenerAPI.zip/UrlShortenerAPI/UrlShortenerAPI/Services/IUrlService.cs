﻿using UrlShortener.Models;

namespace UrlShortenerAPI.Services
{
    // Interface for URL shortening service
    public interface IUrlService
    {
        // Creates a new short URL from the original URL
        Task<UrlResponse> CreateShortUrlAsync(CreateUrlRequest request);

        // Retrieves a URL entry by its short code
        Task<UrlModel?> GetUrlByShortCodeAsync(string shortCode);

        // Gets all stored short URLs
        Task<IEnumerable<UrlResponse>> GetAllUrlsAsync();

        // Increments the click count for a short URL
        Task IncrementClickCountAsync(string shortCode);
    }
}
