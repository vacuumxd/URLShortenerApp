﻿using Microsoft.EntityFrameworkCore;
using UrlShortener.Models;
using System.Text;
using UrlShortenerAPI.Data;

namespace UrlShortenerAPI.Services
{
    public class UrlService : IUrlService
    {
        private readonly UrlContext _context;
        private readonly ILogger<UrlService> _logger;

        public UrlService(UrlContext context, ILogger<UrlService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<UrlResponse> CreateShortUrlAsync(CreateUrlRequest request)
        {
            // Validate the original URL format
            if (!Uri.TryCreate(request.OriginalUrl, UriKind.Absolute, out _))
            {
                throw new ArgumentException("Invalid URL format");
            }

            // Use custom code if provided, otherwise generate a new short code
            var shortCode = !string.IsNullOrEmpty(request.CustomCode)
                ? request.CustomCode
                : GenerateShortCode();

            // Check if short code already exists in the database
            if (await _context.Urls.AnyAsync(u => u.ShortCode == shortCode))
            {
                if (!string.IsNullOrEmpty(request.CustomCode))
                {
                    throw new InvalidOperationException("Custom code already exists");
                }
                // Generate a new code if the generated one conflicts
                shortCode = GenerateShortCode();
            }

            var urlModel = new UrlModel
            {
                OriginalUrl = request.OriginalUrl,
                ShortCode = shortCode,
                CreatedAt = DateTime.UtcNow
            };

            _context.Urls.Add(urlModel);
            await _context.SaveChangesAsync();

            return new UrlResponse
            {
                OriginalUrl = urlModel.OriginalUrl,
                ShortCode = urlModel.ShortCode,
                ShortUrl = $"http://localhost:5000/{urlModel.ShortCode}", // Direct short URL without API path
                CreatedAt = urlModel.CreatedAt,
                ClickCount = urlModel.ClickCount
            };
        }

        public async Task<UrlModel?> GetUrlByShortCodeAsync(string shortCode)
        {
            return await _context.Urls.FirstOrDefaultAsync(u => u.ShortCode == shortCode);
        }

        public async Task<IEnumerable<UrlResponse>> GetAllUrlsAsync()
        {
            var urls = await _context.Urls.OrderByDescending(u => u.CreatedAt).ToListAsync();

            return urls.Select(u => new UrlResponse
            {
                OriginalUrl = u.OriginalUrl,
                ShortCode = u.ShortCode,
                ShortUrl = $"http://localhost:5000/api/url/{u.ShortCode}", // Full API URL
                CreatedAt = u.CreatedAt,
                ClickCount = u.ClickCount
            });
        }

        public async Task IncrementClickCountAsync(string shortCode)
        {
            var url = await _context.Urls.FirstOrDefaultAsync(u => u.ShortCode == shortCode);
            if (url != null)
            {
                url.ClickCount++;
                await _context.SaveChangesAsync();
            }
        }

        // Generates a random 6-character short code
        private string GenerateShortCode()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var random = new Random();
            var result = new StringBuilder(6);

            for (int i = 0; i < 6; i++)
            {
                result.Append(chars[random.Next(chars.Length)]);
            }

            return result.ToString();
        }
    }
}
