﻿using Microsoft.EntityFrameworkCore;
using UrlShortener.Models;

namespace UrlShortenerAPI.Data
{
    // Defines the Entity Framework Core database context for URL data
    public class UrlContext : DbContext
    {
        // Constructor that passes options to the base DbContext
        public UrlContext(DbContextOptions<UrlContext> options) : base(options) { }

        // DbSet representing the UrlModel table
        public DbSet<UrlModel> Urls { get; set; }

        // Configures the model using Fluent API
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<UrlModel>(entity =>
            {
                entity.HasKey(e => e.Id);                        // Sets primary key
                entity.Property(e => e.OriginalUrl).IsRequired(); // Requires OriginalUrl
                entity.Property(e => e.ShortCode).IsRequired();   // Requires ShortCode
                entity.HasIndex(e => e.ShortCode).IsUnique();     // Unique constraint on ShortCode
            });
        }
    }
}
