﻿using Microsoft.AspNetCore.Mvc;

namespace UrlShortenerApi.Controllers
{
    // Marks this class as an API controller and sets the route prefix to "api/about"
    [ApiController]
    [Route("api/[controller]")]
    public class AboutController : ControllerBase
    {
        // GET: /api/about/info
        // Returns application metadata such as version, release date, features, and developers
        [HttpGet("info")]
        public IActionResult GetAppInfo()
        {
            var appInfo = new
            {
                Version = GetAssemblyVersion(), // Retrieves the current app version
                ReleaseDate = "2025-06-15",     // Static release date
                Features = new[]                // List of app features
                {
                    "Shortening long URLs",
                    "Click analytics",
                    "Custom aliases",
                    "QR codes for links",
                    "Link management",
                    "Geolocation statistics",
                    "Data export"
                },
                Developers = new[]              // Developer contact info
                {
                    new { Name = "Vyrodov Vyacheslav", Role = "Full Stack Developer", Email = "vyrodovslava@gmail.com" }
                }
            };

            return Ok(appInfo); // Returns 200 OK with app info
        }

        // Returns the assembly version as a string
        private string GetAssemblyVersion()
        {
            var version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
            return version?.ToString() ?? "1.0.0";
        }
    }
}
