﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using UrlShortenerAPI.Services;

namespace UrlShortenerAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly ILogger<AuthController> _logger;
        private readonly IJwtService _jwtService;

        // Inject logger and JWT service
        public AuthController(ILogger<AuthController> logger, IJwtService jwtService)
        {
            _logger = logger;
            _jwtService = jwtService;
        }

        // POST: /api/auth/login
        // Authenticates a user and returns a JWT token
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest request)
        {
            try
            {
                _logger.LogInformation("Login attempt for user: {Username}", request?.Username);

                if (request == null)
                    return BadRequest(new { error = "Request body is required" });

                if (string.IsNullOrEmpty(request.Username) || string.IsNullOrEmpty(request.Password))
                    return BadRequest(new { error = "Username and password are required" });

                // Basic authentication check (use database in real scenarios)
                if (request.Username == "testuser" && request.Password == "password")
                {
                    _logger.LogInformation("Login successful for user: {Username}", request.Username);

                    var userId = "1";
                    var email = "test@example.com";

                    // Generate JWT token
                    var token = _jwtService.GenerateToken(userId, request.Username, email);
                    var expires = DateTime.UtcNow.AddHours(24).ToString("O");

                    return Ok(new AuthResponse
                    {
                        Token = token,
                        User = new UserInfo
                        {
                            Id = userId,
                            Username = request.Username,
                            Email = email,
                            CreatedAt = DateTime.UtcNow.ToString("O")
                        },
                        Expires = expires
                    });
                }

                _logger.LogWarning("Login failed for user: {Username}", request.Username);
                return BadRequest(new { error = "Invalid username or password" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during login");
                return BadRequest(new { error = "Login failed: " + ex.Message });
            }
        }

        // POST: /api/auth/register
        // Registers a new user and returns a JWT token
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterRequest request)
        {
            try
            {
                _logger.LogInformation("Registration attempt for user: {Username}", request?.Username);

                if (request == null)
                    return BadRequest(new { error = "Request body is required" });

                if (string.IsNullOrEmpty(request.Username) || string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.Password))
                    return BadRequest(new { error = "Username, email and password are required" });

                if (request.Password != request.ConfirmPassword)
                    return BadRequest(new { error = "Passwords do not match" });

                _logger.LogInformation("Registration successful for user: {Username}", request.Username);

                var userId = Guid.NewGuid().ToString();

                // Generate JWT token for new user
                var token = _jwtService.GenerateToken(userId, request.Username, request.Email);
                var expires = DateTime.UtcNow.AddHours(24).ToString("O");

                return Ok(new AuthResponse
                {
                    Token = token,
                    User = new UserInfo
                    {
                        Id = userId,
                        Username = request.Username,
                        Email = request.Email,
                        CreatedAt = DateTime.UtcNow.ToString("O")
                    },
                    Expires = expires
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during registration");
                return BadRequest(new { error = "Registration failed: " + ex.Message });
            }
        }

        // GET: /api/auth/check-username/{username}
        // Checks if the username is available
        [HttpGet("check-username/{username}")]
        public async Task<IActionResult> CheckUsernameAvailability(string username)
        {
            try
            {
                _logger.LogInformation("Checking username availability: {Username}", username);
                var available = username != "testuser";
                return Ok(new { available });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking username availability");
                return StatusCode(500, new { error = "Error checking username" });
            }
        }

        // GET: /api/auth/check-email/{email}
        // Checks if the email is available
        [HttpGet("check-email/{email}")]
        public async Task<IActionResult> CheckEmailAvailability(string email)
        {
            try
            {
                _logger.LogInformation("Checking email availability: {Email}", email);
                var available = email != "test@example.com";
                return Ok(new { available });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error checking email availability");
                return StatusCode(500, new { error = "Error checking email" });
            }
        }

        // POST: /api/auth/forgot-password
        // Placeholder for sending password reset email
        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordRequest request)
        {
            try
            {
                _logger.LogInformation("Password reset requested for: {Email}", request?.Email);
                return Ok(new { message = "Password reset email sent" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during password reset request");
                return StatusCode(500, new { error = "Password reset failed" });
            }
        }

        // POST: /api/auth/reset-password
        // Placeholder for resetting the password
        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest request)
        {
            try
            {
                _logger.LogInformation("Password reset attempt");
                return Ok(new { message = "Password reset successful" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during password reset");
                return StatusCode(500, new { error = "Password reset failed" });
            }
        }

        // POST: /api/auth/refresh
        // Returns a new JWT token (stubbed data)
        [HttpPost("refresh")]
        public async Task<IActionResult> RefreshToken()
        {
            try
            {
                _logger.LogInformation("Token refresh requested");

                // Dummy user data, replace with actual auth logic
                var userId = "1";
                var username = "testuser";
                var email = "test@example.com";

                var token = _jwtService.GenerateToken(userId, username, email);
                var expires = DateTime.UtcNow.AddHours(24).ToString("O");

                return Ok(new AuthResponse
                {
                    Token = token,
                    User = new UserInfo
                    {
                        Id = userId,
                        Username = username,
                        Email = email,
                        CreatedAt = DateTime.UtcNow.ToString("O")
                    },
                    Expires = expires
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during token refresh");
                return StatusCode(500, new { error = "Token refresh failed" });
            }
        }
    }

    // DTOs used in authentication logic

    public class RegisterRequest
    {
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string ConfirmPassword { get; set; } = string.Empty;
    }

    public class LoginRequest
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    public class AuthResponse
    {
        public string Token { get; set; } = string.Empty;
        public UserInfo User { get; set; } = new UserInfo();
        public string Expires { get; set; } = string.Empty;
    }

    public class UserInfo
    {
        public string Id { get; set; } = string.Empty;
        public string Username { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string CreatedAt { get; set; } = DateTime.UtcNow.ToString("O");
    }

    public class ForgotPasswordRequest
    {
        public string Email { get; set; } = string.Empty;
    }

    public class ResetPasswordRequest
    {
        public string Token { get; set; } = string.Empty;
        public string NewPassword { get; set; } = string.Empty;
    }
}
