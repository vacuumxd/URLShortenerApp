using Microsoft.AspNetCore.Mvc;
using UrlShortener.Models;
using UrlShortenerAPI.Services;

namespace UrlShortener.Controllers
{
    // Declares this class as an API controller with route prefix "api/url"
    [ApiController]
    [Route("api/[controller]")]
    public class UrlController : ControllerBase
    {
        private readonly IUrlService _urlService;

        // Constructor injection of the URL service
        public UrlController(IUrlService urlService)
        {
            _urlService = urlService;
        }

        // POST: /api/url
        // Creates a new shortened URL
        [HttpPost]
        public async Task<IActionResult> CreateShortUrl([FromBody] CreateUrlRequest request)
        {
            try
            {
                var result = await _urlService.CreateShortUrlAsync(request);
                return Ok(result); // Returns the shortened URL info
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { error = ex.Message }); // Validation error
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(new { error = ex.Message }); // Conflict (e.g., alias already taken)
            }
        }

        // GET: /api/url/{shortCode}
        // Redirects to the original URL based on the short code
        [HttpGet("{shortCode}")]
        public async Task<IActionResult> RedirectToOriginal(string shortCode)
        {
            var url = await _urlService.GetUrlByShortCodeAsync(shortCode);
            if (url == null)
            {
                return NotFound(new { error = "Short URL not found" });
            }

            await _urlService.IncrementClickCountAsync(shortCode); // Track clicks

            var encodedUrl = Uri.EscapeUriString(url.OriginalUrl); // Encode before redirect
            return Redirect(encodedUrl);
        }

        // GET: /api/url
        // Retrieves all stored URLs
        [HttpGet]
        public async Task<IActionResult> GetAllUrls()
        {
            var urls = await _urlService.GetAllUrlsAsync();
            return Ok(urls);
        }
    }
}
