using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using UrlShortenerAPI.Data;
using UrlShortenerAPI.Services;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// Configure URLs the app will listen on
builder.WebHost.UseUrls("http://localhost:5000", "https://localhost:5001");

// Add services to the container
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<IJwtService, JwtService>();

// Configure Entity Framework with In-Memory database
builder.Services.AddDbContext<UrlContext>(options =>
    options.UseInMemoryDatabase("UrlShortenerDb"));

// Register application services
builder.Services.AddScoped<IUrlService, UrlService>();
builder.Services.AddScoped<IJwtService, JwtService>();

// JWT configuration
var jwtSecretKey = builder.Configuration["Jwt:SecretKey"] ?? "your-super-secret-key-that-is-at-least-32-characters-long";

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecretKey)),
            ValidateIssuer = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"] ?? "UrlShortenerAPI",
            ValidateAudience = true,
            ValidAudience = builder.Configuration["Jwt:Audience"] ?? "UrlShortenerClient",
            ValidateLifetime = true,
            ClockSkew = TimeSpan.Zero
        };
    });

// Configure CORS policy for development
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowDevelopment", policy =>
    {
        policy.WithOrigins(
                "http://localhost:4200",
                "http://localhost:5000",
                "https://localhost:5001"
              )
              .AllowAnyMethod()
              .AllowAnyHeader()
              .AllowCredentials();
    });
});

// Add logging for debugging purposes
builder.Services.AddLogging(logging =>
{
    logging.AddConsole();
    logging.SetMinimumLevel(LogLevel.Information);
});

var app = builder.Build();

// Configure HTTP request pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors("AllowDevelopment");
app.UseAuthentication(); // Enable authentication
app.UseAuthorization();

// Route for redirecting short URLs
app.MapGet("/{shortCode}", async (string shortCode, IUrlService urlService) =>
{
    var url = await urlService.GetUrlByShortCodeAsync(shortCode);
    if (url == null)
    {
        return Results.NotFound("Short URL not found");
    }
    await urlService.IncrementClickCountAsync(shortCode);

    var encodedUrl = Uri.EscapeUriString(url.OriginalUrl);
    return Results.Redirect(encodedUrl);
});

app.MapControllers();

// Log startup information
app.Logger.LogInformation("=== Application Starting ===");
app.Logger.LogInformation("HTTP Endpoint: http://localhost:5000");
app.Logger.LogInformation("HTTPS Endpoint: https://localhost:5001");
app.Logger.LogInformation("Swagger UI: http://localhost:5000/swagger");
app.Logger.LogInformation("JWT Authentication: Enabled");

app.Run();
